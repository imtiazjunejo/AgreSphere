import React from 'react'

const SettingsPage = () => {
  return (
    <div>
      Settings page
    </div>
  )
}

export default SettingsPage
